# Validation report — mslearn-databricks AI exercises (AI-01 to AI-07)

**Validated:** 19 October 2026 · **Source:** `MicrosoftLearning/mslearn-databricks` `main` @ `8ed69f6` (last commit 5 May 2026) · **Prepared by:** Jayaprakash Balakrishnan

## 1. How the labs were validated — read this first

No live Azure subscription or Databricks workspace was available for this pass, so **no exercise was run end-to-end in Azure Databricks or Azure OpenAI**. Each step was validated at the strongest level possible without one:

| Level | What it means |
|---|---|
| **Executed** | The lab's own code (extracted from the rendered Markdown) was run in Python 3.12 with the libraries the lab installs. Cloud calls were replaced by a mocked Azure OpenAI HTTP endpoint, fake LangChain embeddings/LLM, or tiny randomly-initialised models of the same architecture (BART, GPT-2). |
| **API-verified** | Imports, classes and parameter names were checked by introspecting the installed package (`inspect.signature`). |
| **Doc-verified** | Checked against official Microsoft / Databricks / PyPI documentation on 19 Oct 2026 (sources in section 4). |
| **Not verified** | Could only be confirmed in a live tenant. Listed in section 5 as pre-delivery checks. |

Every Python code block in all seven labs was also extracted exactly as Markdown renders it and syntax-checked (`ast.parse`); after the fixes, **all blocks parse cleanly**.

Library versions resolved and tested on 19 Oct 2026: transformers 4.53.0 + torch 2.14.1; databricks-vectorsearch 0.56 (also checked 0.75); langchain-classic 1.0.8, langchain-openai 1.7.2, langchain-community 0.4.2, faiss-cpu 1.15.1; mlflow 3.17.1; openai 3.35.1, 2.47.0 and 1.69.0 (the version pre-installed in DBR 17.3 LTS ML).

## 2. Summary by lab

| Lab | Result before fixes | Blocking errors found | Status after fixes |
|---|---|---|---|
| AI-01 Explore LLMs | No errors found | 0 | Unchanged |
| AI-02 RAG | Fails at summarisation / generation on long pages | 2 | Fixed, executed offline |
| AI-03 Multi-stage reasoning | Fails at 2 cells (syntax error, bad import) | 2 | Fixed, executed offline |
| AI-04 Fine-tune models | Runs, but status check is wrong and deployment step fails if tokens expire | 2 | Fixed, API-verified + executed with fakes |
| AI-05 Evaluate models | Placeholder API version breaks every call if pasted literally | 1 | Fixed, executed offline |
| AI-06 Responsible AI | Placeholder API version; "analysis" step didn't analyse | 1 | Fixed, executed offline |
| AI-07 LLMOps | Placeholder API version | 1 | Fixed, executed offline |

## 3. Corrections log

### Shared across AI-03, AI-05, AI-06, AI-07 (Azure OpenAI labs)

| # | Problem | Fix | Evidence |
|---|---|---|---|
| C1 | `AZURE_OPENAI_API_VERSION` was set to the literal text `"your_model_version_example: '2023-03-15-preview'"`. The client accepts it at construction and every request then fails. It also confuses API version with model version. | Set to `"2024-10-21"` (dated GA data-plane version) with a comment. | Executed: placeholder accepted at construction, fails at request time. Doc-verified: 2024-10-21 is a GA release. |
| C2 | "Model version: *Use default version*" for gpt-4o. gpt-4o 2024-05-13 and 2024-08-06 are **Deprecated** (blocked for most new deployments); only 2024-11-20 (**Legacy**) is still deployable. | Pinned **2024-11-20**; added a retirement note (14 Apr 2027) with a Global Standard fallback and a link to the retirement schedule. | Doc-verified. |
| C3 | Prerequisite "subscription approved for access to the Azure OpenAI service" — this application requirement has been removed. | Changed to "Select your Azure subscription". | Doc-verified. |
| C4 | Foundry navigation referred only to a **Deployments** page. Current docs use **Build > Models** in the New Foundry portal. | Instructions now name both the classic and new navigation. | Doc-verified (new portal); classic name retained for tenants without the toggle. |

### AI-01 Explore LLMs

No changes. The revision pins (`714eb0f`, `a9723ea`, `d7645e1`) are the same short SHAs transformers 4.53.0 uses for its own pipeline defaults, so they resolve correctly (API-verified in the installed source). The Hugging Face Hub was unreachable from the validation sandbox, so the four real models were not downloaded (see section 5).

### AI-02 RAG

| # | Problem | Fix | Evidence |
|---|---|---|---|
| C5 | **Blocking.** The BART summariser has a 1,024-token input limit and the call had no truncation. The query can retrieve *List of anthropologists* (~9,000 characters), and 361 of the 582 pages exceed ~4,000 characters. Long input raises `IndexError: index out of range in self`. | Added `truncation=True`; reduced summary length to 50–200 tokens. | Executed: as-written fails with IndexError; fixed version runs on a 3,000-token page. |
| C6 | **Blocking.** GPT-2 `generate(max_length=300)` counts the prompt. In transformers 4.53 a prompt over 300 tokens raises `ValueError`, and prompts over 1,024 tokens raise `IndexError`. | Used `max_new_tokens=150`, truncated the prompt to 800 tokens, passed the attention mask, and set `pad_token_id`. | Executed: both failures reproduced, fix runs with a 1,500-token prompt. |
| C7 | The vector-search endpoint was created without waiting for it, then the index was created straight away. Re-running the cell fails because the endpoint already exists. Learners had to check the UI by hand. | Uses `create_endpoint_and_wait` / `wait_for_endpoint`, reuses an existing index, and calls `index.wait_until_ready()`. | API-verified in SDK 0.56 and 0.75; control flow executed with a fake client (both the create and the reuse paths). |
| C8 | `SparkSession.builder.appName(...).getOrCreate()` is unnecessary on serverless (Spark Connect) and implies settings that serverless ignores. | Removed; uses the notebook's `spark`. | Doc-verified (partially). |
| C9 | Retrieved text went through a single-row Spark DataFrame with auto-named `_2` columns. | Read `data_array` directly. | Executed. |
| C10 | Catalog-name guidance said the catalog always matches the workspace name. | Now tells learners to confirm it under **Catalog**, as AI-04 already does. | — |
| C11 | Typos ("enchance", "refresh the its pane"), list numbering, and a note that Vector Search is now shown as **AI Search** in newer UIs; added a note that GPT-2 output quality is expected to be low. | Corrected. | Doc-verified (rename). |

### AI-03 Multi-stage reasoning

| # | Problem | Fix | Evidence |
|---|---|---|---|
| C12 | **Blocking.** Missing comma after `openai_api_version="2023-03-15-preview"` → `SyntaxError`. | Fixed; parameters renamed to the current `azure_deployment` / `api_key` / `api_version`. | Executed. |
| C13 | **Blocking.** `from langchain.community_vectorstores import FAISS` → `ModuleNotFoundError`. | `from langchain_community.vectorstores import FAISS`. | Executed. |
| C14 | `langchain_classic` was imported but never installed explicitly. It only arrived as a side effect of another package. | `%pip install` now names `langchain-classic`, `langchain-openai` and `langchain-community`, with major-version ranges for stability. | Executed in a clean environment. |
| C15 | `{"summary": qa_chain1}` passed the **whole result dictionary** (input, Document objects and answer) into the social-post prompt. | `qa_chain1 | itemgetter("answer")`. | Executed: captured prompt before and after. |
| C16 | The `faiss.IndexFlatL2` object was created and never used, without explanation. | Now prints the embedding dimension, explains it, and confirms the credentials work. | — |
| C17 | `text-embedding-ada-002` model version was not pinned. | Pinned version **2** (GA, retires 9 Feb 2028). | Doc-verified. |

### AI-04 Fine-tune models

| # | Problem | Fix | Evidence |
|---|---|---|---|
| C18 | **Blocking.** The status cell printed the `response` object from job creation, which never updates, so learners never see `succeeded`. | Calls `jobs.retrieve()` and lists the latest events. | API-verified on openai 1.69.0 (DBR 17.3 ML); executed with a fake client. |
| C19 | **Blocking.** Entra tokens from Cloud Shell typically expire in about an hour, but training usually takes longer, so the deployment and chat calls fail with 401. | Added a token-expiry warning and a "refresh tokens" step before deployment. | Partially verified (default token lifetime). |
| C20 | The chat call ran immediately after the deployment request, but provisioning takes minutes. | Added a cell that polls `provisioningState`. | Executed with a fake `requests`. |
| C21 | The "Important" note said `DefaultAzureCredential` runs as the workspace managed identity and referenced a non-existent `TEMP_AUTH_TOKEN`. | Rewritten: explains the user-token approach, names the correct variable, and gives a 401/403 role fix. | — |
| C22 | Token counting used `cl100k_base`; GPT-4.1 uses `o200k_base`. | Corrected. | Doc-verified. |
| C23 | **Unverified claims removed:** a 1,047,576 / 300,000-token context statement. Replaced with a link to the docs and Microsoft's ≥50-example guidance (verified). | Replaced. | Doc-verified. |
| C24 | The test prompt (customer-managed keys) had nothing to do with the training data (a sarcastic "Clippy" trivia bot), so the fine-tuning effect was invisible. | Uses the Clippy system message and a trivia question, and explains what to look for. | Data file inspected. |
| C25 | gpt-4.1 base model is **Deprecated** and may not be deployable for new subscriptions. The fine-tuning job doesn't need a base deployment. | Base deployment marked *optional*, with a retirement note. | Doc-verified. |
| C26 | Clean-up didn't mention that Standard fine-tuned deployments bill hourly hosting. | Added a cost warning. | Doc-verified (hourly hosting fee on Standard / Global Standard). |

The training and validation JSONL files were checked: 10 + 10 examples, each system → user → assistant, valid JSON. The token-count script was executed on them with a stub encoder.

### AI-05 Evaluate models

| # | Problem | Fix | Evidence |
|---|---|---|---|
| C27 | `databricks-connect` was installed inside a Databricks notebook. It is a local-IDE client that conflicts with pyspark. | Removed from `%pip install`. | Doc-verified (partially). |
| C28 | Built-in `Guidelines` and `Safety` judges run on Databricks-hosted models. If partner-powered AI features are off, `evaluate()` **completes without raising** but every score is an error, which is easy to miss. | Added a troubleshooting note. | Executed: every judge failed silently outside Databricks; the flow ran fully with a custom scorer. |
| C29 | Typo "appropiate" inside the judge guideline text. | Corrected. | — |

### AI-06 Responsible AI

| # | Problem | Fix | Evidence |
|---|---|---|---|
| C30 | The step said it would "analyze for gender bias" but only displayed the text. | Added a pronoun-count cell for the neutral prompts and explained how to read it. | Executed. |
| C31 | Mitigation text proposed re-weighting or re-sampling **training data**, which isn't possible for a hosted gpt-4o. | Now covers prompt-level mitigation, content filters and re-measurement first, with data techniques for models you train yourself. | — |
| C32 | "Describe a engineer"; inconsistent indentation of one line (fine when rendered, breaks when copied from the raw file). | Corrected. | Executed. |

### AI-07 LLMOps

| # | Problem | Fix | Evidence |
|---|---|---|---|
| C33 | Token count was logged as a **param**, so it can't be charted or compared numerically. | Logs `prompt_tokens` and `completion_tokens` as metrics, and model and system prompt as params. | Executed: run shows 2 metrics and 2 params, and the trace is linked to the run. |
| C34 | Redundant `mlflow.end_run()` after the `with` block; the step said "log the model" when no model is logged. | Removed; wording corrected. | — |
| C35 | `%pip install openai mlflow` could leave the older pre-installed MLflow in place. | `--upgrade openai "mlflow[databricks]>=3.1.0"`, matching AI-05. | — |

## 4. Verification register (version-sensitive facts used in the labs)

| Fact | Status on 19 Oct 2026 | Re-check before each delivery | Source |
|---|---|---|---|
| gpt-4o 2024-11-20: Legacy, retires 14 Apr 2027; 2024-05-13 and 2024-08-06 Deprecated | Doc-verified | **Yes** — the labs break after the retirement date | [Model retirement schedule](https://learn.microsoft.com/en-us/azure/foundry/openai/concepts/model-retirement-schedule) |
| gpt-4.1 2025-04-14: Deprecated, retires 14 Apr 2027; fine-tuned deployments retire 14 Oct 2027 | Doc-verified | **Yes** | Same + [Fine-tuning overview](https://learn.microsoft.com/en-us/azure/foundry/fine-tuning/overview) |
| Fine-tuned gpt-4.1 Standard deployment available in North Central US and Sweden Central | Doc-verified (deployment list; training-region list not published per tier) | Yes | [Deploy fine-tuned models](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/fine-tuning-deploy) |
| Standard fine-tuned deployments bill an hourly hosting fee | Doc-verified | Yes (price) | [Fine-tuning cost management](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/fine-tuning-cost-management) |
| text-embedding-ada-002 v2 GA, retires 9 Feb 2028 | Doc-verified | Annually | Retirement schedule |
| `2024-10-21` is a GA data-plane API version; `v1` is the newest GA surface | Doc-verified | Yes | [API version lifecycle](https://learn.microsoft.com/en-us/azure/foundry/openai/api-version-lifecycle), [REST reference](https://learn.microsoft.com/azure/foundry/openai/reference) |
| Azure OpenAI no longer needs an access application (except Limited Access models) | Doc-verified | Annually | [Limited access](https://learn.microsoft.com/en-us/azure/foundry/responsible-ai/openai/limited-access) |
| DBR 17.3 LTS ML ships openai 1.69.0, tiktoken 0.9.0, mlflow-skinny 3.0.1, transformers 4.51.3 | Doc-verified | When the runtime changes | [17.3 LTS ML release notes](https://learn.microsoft.com/en-us/azure/databricks/release-notes/runtime/17.3lts-ml) |
| `databricks-vectorsearch` is deprecated in favour of `databricks-ai-search`; 0.75 still exposes `VectorSearchClient` | Doc-verified + API-verified | **Yes** — decide when to migrate | [PyPI](https://pypi.org/project/databricks-vectorsearch/) |
| `databricks-gte-large-en`: available, 8,192-token input window | Doc-verified | Yes | [Supported models](https://learn.microsoft.com/en-us/azure/databricks/machine-learning/foundation-model-apis/supported-models) |
| Serverless supports `spark.read.format("xml")` | Doc-verified | — | [Serverless limitations](https://learn.microsoft.com/en-us/azure/databricks/compute/serverless/limitations) |
| GPT-4o / GPT-4.1 use `o200k_base` | Verified (tiktoken source) | — | [tiktoken model.py](https://github.com/openai/tiktoken/blob/main/tiktoken/model.py) |

## 5. Open items — check in a live tenant before delivery

1. **Run each lab once end-to-end in a real workspace.** Nothing here replaces that.
2. **AI-02 embedding length (not verified).** 30%+ of wiki pages are far longer than gte-large-en's 8,192-token window (p90 ≈ 129,000 characters). It is not documented whether the endpoint truncates or rejects such rows during index sync. If the sync reports failures, chunk the text (or `substring()` it to about 25,000 characters) before indexing.
3. **AI-02 `%sh wget` on serverless (not verified).** Outbound access depends on the account's serverless network policy.
4. **AI-01 / AI-02 Hugging Face downloads (not verified).** The Hub was unreachable from the validation sandbox, so the real checkpoints weren't loaded (the logic was tested with same-architecture tiny models).
5. **AI-04 fine-tuning job behaviour (not verified):** training time, regional training capacity, and the data-plane role your learners' accounts actually receive on a new Foundry resource.
6. **Foundry portal labels (partially verified).** The "Go to Foundry portal" button wording on the resource Overview page could not be confirmed from the docs.

## 6. Decisions for the course owner

- **gpt-4o and gpt-4.1 both retire on 14 April 2027.** This pass kept them (pinned and annotated) to keep the change set small. Microsoft lists gpt-5.1 as the replacement for gpt-4o. Migrating is a separate piece of work: newer models may reject parameters these labs use (e.g. `max_tokens` in AI-06), and I have not verified gpt-5.1's parameter support.
- **Vector Search SDK.** Kept the `databricks-vectorsearch==0.56` pin (APIs confirmed). Moving to `databricks-ai-search` should be scheduled before the forwarding package is removed.
- **`langchain-community` is being sunset.** AI-03 still works with it (tested). `langchain_core`'s `InMemoryVectorStore` would remove that dependency if you'd rather not depend on FAISS.

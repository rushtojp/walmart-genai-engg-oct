# mslearn-databricks AI labs: solution notebooks

The `solution/` folder has a copy of each lab notebook (`AI-0x-..._Solution.ipynb`). The `lab/` folder has the learner notebooks without solutions.

## What each solution notebook adds

After **every code cell** there is a solution cell with three parts:

| Part | Meaning |
|---|---|
| **Solution: expected output** | Output that the code itself determines, or that was captured by running the same code on the lab's data. For example, the AI-02 Spark table and schema outputs were captured with PySpark 4.2 on the lab's XML file. |
| **Solution: sample output** | A representative example of what a correct result looks like. It is **not** captured from a live Azure or Databricks run, so model text, scores, IDs and timings will differ. |
| **What to check** / **If the resource is unavailable** | How to tell whether the cell worked, common errors, and what to do if the resource is missing. |

Where a missing resource would block the rest of a lab, there is also an **offline fallback** cell. It does nothing unless you set `USE_OFFLINE_FALLBACK = True` in that cell.

| Lab | Fallback | What it replaces |
|---|---|---|
| AI-01 | none | Needs Hugging Face downloads; the sample outputs let learners follow along. |
| AI-02 | 2 cells | Vector Search → keyword retrieval over the `wiki_pages` Delta table. BART summariser → the first sentences of the page with wiki markup stripped. (GPT-2 generation has no substitute.) |
| AI-03 | 2 cells | Azure OpenAI embeddings → `DeterministicFakeEmbedding`; gpt-4o → `FakeListChatModel` with canned answers, then the chains are rebuilt. |
| AI-04 | none | Fine-tuning needs a Foundry resource; the sample outputs cover the job, deployment and test steps. |
| AI-05, AI-06, AI-07 | 1 cell each | gpt-4o → an offline client with the same `client.chat.completions.create(...)` call shape, returning canned replies. |

**Offline mode, step by step:**

1. In the configuration cell, enter `https://offline.invalid` as the endpoint and `offline` as the key, so its placeholder check passes.
2. When a cell fails because the resource is missing, set `USE_OFFLINE_FALLBACK = True` in the fallback cell that follows it, run that cell, and continue.

Every offline reply starts with `[OFFLINE SAMPLE]`, so it can't be mistaken for real model output.

**Limits of offline mode:**

- Fake embeddings make retrieval ranking meaningless in AI-03.
- AI-07 logs its parameters and metrics but no MLflow trace, because autologging only traces the real OpenAI client.
- The AI-05 judges still need Databricks-hosted models.

## How these were checked

- **Format:** all 14 notebooks validate against the Jupyter notebook schema, every code cell is valid Python, and every code cell is followed by its solution cell.
- **Offline runs:** AI-03, AI-05, AI-06 and AI-07 were run top to bottom in offline mode (Databricks-only cells skipped). The AI-02 fallbacks were run in local Spark against the real `enwiki` data file.
- **Fallback outputs:** each documented "Expected output when the fallback is used" matched the real output exactly (7 of 7).
- **Not run in a live Azure Databricks workspace.** The sample outputs are guidance, not recorded results. Once you have run the labs in a real workspace, you can replace them with captured outputs.
